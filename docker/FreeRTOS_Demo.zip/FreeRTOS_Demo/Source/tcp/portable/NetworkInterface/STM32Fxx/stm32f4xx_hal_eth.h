/*
 * The Ethernet header files for STM32F2, STM32F4 and STM32F7 have been merged to
 * a single module that works for both parts: "stm32fxx_hal_eth"
 */

#include "stm32fxx_hal_eth.h"
