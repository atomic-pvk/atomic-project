Update pack_struct_start.h and pack_struct_end.h for your architecure.
These files define the specifiers needed by your compiler to properly pack struct data
need by FreeRTOS+TCP.
