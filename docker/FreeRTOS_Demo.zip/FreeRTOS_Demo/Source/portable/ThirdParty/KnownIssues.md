# Known Issues
This document lists the known issues in various FreeRTOS third
party ports.

## ThirdParty/GCC/ARC_EM_HS
* [Memory Read Protection Violation from Secure MPU on exit from
interrupt](https://github.com/FreeRTOS/FreeRTOS-Kernel/issues/331)
